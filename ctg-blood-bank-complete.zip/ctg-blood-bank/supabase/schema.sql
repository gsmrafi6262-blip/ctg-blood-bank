-- CTG Blood Bank reference schema for a fresh Supabase project.
-- Use migrations for existing databases; this file does not change existing columns.
create extension if not exists pgcrypto;
create schema if not exists private;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  phone text,
  role text not null default 'user' check (role in ('user','donor','staff','admin')),
  created_at timestamptz not null default now()
);
create table if not exists public.hospitals (
  id uuid primary key default gen_random_uuid(), name text not null, district text, address text, phone text, created_at timestamptz not null default now()
);
create table if not exists public.donors (
  id uuid primary key default gen_random_uuid(), user_id uuid references public.profiles(id) on delete set null,
  donor_code text unique, full_name text not null, phone text not null, email text,
  date_of_birth date, gender text, blood_group text not null check (blood_group in ('A+','A-','B+','B-','AB+','AB-','O+','O-')),
  district text not null, upazila text, address text, available boolean not null default false, emergency_available boolean not null default false,
  last_donation_date date, total_donations int not null default 0, status text not null default 'pending', created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table if not exists public.donor_screenings (
  id uuid primary key default gen_random_uuid(), donor_id uuid not null references public.donors(id), staff_user_id uuid references public.profiles(id),
  screening_date timestamptz not null default now(), result text not null default 'pending', notes text, next_eligible_date date, created_at timestamptz not null default now()
);
create table if not exists public.donations (
  id uuid primary key default gen_random_uuid(), donor_id uuid not null references public.donors(id), staff_user_id uuid references public.profiles(id),
  donation_code text unique, collection_date timestamptz not null default now(), collected_volume_ml int, collection_type text, status text not null default 'collected', notes text, created_at timestamptz not null default now()
);
create table if not exists public.blood_units (
  id uuid primary key default gen_random_uuid(), donation_id uuid references public.donations(id), bag_code text unique, qr_code text, barcode text,
  blood_group text not null check (blood_group in ('A+','A-','B+','B-','AB+','AB-','O+','O-')), component text not null default 'whole_blood', volume_ml int,
  collected_at timestamptz, expires_at timestamptz, status text not null default 'quarantine', storage_location text, created_at timestamptz not null default now()
);
create table if not exists public.lab_tests (
  id uuid primary key default gen_random_uuid(), blood_unit_id uuid references public.blood_units(id), staff_user_id uuid references public.profiles(id),
  test_name text not null, result text, result_status text not null default 'pending', tested_at timestamptz, notes text, created_at timestamptz not null default now()
);
create table if not exists public.processing_records (
  id uuid primary key default gen_random_uuid(), blood_unit_id uuid references public.blood_units(id), staff_user_id uuid references public.profiles(id),
  component text, processed_at timestamptz not null default now(), status text not null default 'pending', notes text, created_at timestamptz not null default now()
);
create table if not exists public.blood_requests (
  id uuid primary key default gen_random_uuid(), request_code text unique, requester_user_id uuid references public.profiles(id), patient_name text not null,
  patient_age int, patient_gender text, blood_group text not null, component text, units int not null check (units > 0), hospital_id uuid references public.hospitals(id), hospital_name text,
  district text, phone text not null, urgency text not null default 'normal', needed_by timestamptz, reason text, status text not null default 'pending', created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table if not exists public.compatibility_tests (
  id uuid primary key default gen_random_uuid(), blood_request_id uuid references public.blood_requests(id), blood_unit_id uuid references public.blood_units(id), staff_user_id uuid references public.profiles(id),
  test_result text not null default 'pending', tested_at timestamptz, notes text, created_at timestamptz not null default now()
);
create table if not exists public.blood_issues (
  id uuid primary key default gen_random_uuid(), issue_code text unique, blood_request_id uuid references public.blood_requests(id), blood_unit_id uuid references public.blood_units(id), staff_user_id uuid references public.profiles(id),
  issued_at timestamptz not null default now(), status text not null default 'pending', notes text, created_at timestamptz not null default now()
);
create table if not exists public.transfusion_records (
  id uuid primary key default gen_random_uuid(), blood_issue_id uuid references public.blood_issues(id), staff_user_id uuid references public.profiles(id),
  started_at timestamptz, completed_at timestamptz, reaction_reported boolean not null default false, reaction_notes text, outcome text, created_at timestamptz not null default now()
);
create table if not exists public.audit_logs (
  id bigint generated always as identity primary key, actor_id uuid references public.profiles(id), action text not null, entity text not null, entity_id text,
  details jsonb not null default '{}'::jsonb, created_at timestamptz not null default now()
);

create or replace function private.is_bloodbank_staff()
returns boolean language sql stable security definer set search_path = public, auth
as $$ select exists(select 1 from public.profiles p where p.id=auth.uid() and p.role in ('staff','admin')) $$;
create or replace function private.is_bloodbank_admin()
returns boolean language sql stable security definer set search_path = public, auth
as $$ select exists(select 1 from public.profiles p where p.id=auth.uid() and p.role='admin') $$;
revoke all on function private.is_bloodbank_staff() from public;
revoke all on function private.is_bloodbank_admin() from public;
grant usage on schema private to authenticated;
grant execute on function private.is_bloodbank_staff(), private.is_bloodbank_admin() to authenticated;

create or replace function public.handle_new_user_profile()
returns trigger language plpgsql security definer set search_path = public
as $$ begin insert into public.profiles(id,full_name,phone,role) values(new.id,new.raw_user_meta_data->>'full_name',new.raw_user_meta_data->>'phone','user') on conflict(id) do nothing; return new; end $$;
drop trigger if exists on_auth_user_created_profile on auth.users;
create trigger on_auth_user_created_profile after insert on auth.users for each row execute function public.handle_new_user_profile();

-- Restrictive access defaults. Donor contact data is not public-searchable; staff and donor owner only.
DO $$ declare t text; begin foreach t in array['profiles','hospitals','donors','donor_screenings','donations','blood_units','lab_tests','processing_records','blood_requests','compatibility_tests','blood_issues','transfusion_records','audit_logs'] loop execute format('alter table public.%I enable row level security',t); end loop; end $$;
-- Policies for fresh installations (policy names are unique in this schema).
create policy "profile self or staff select" on public.profiles for select to authenticated using(id=auth.uid() or private.is_bloodbank_staff());
create policy "profiles admin update" on public.profiles for update to authenticated using(private.is_bloodbank_admin()) with check(private.is_bloodbank_admin());
create policy "hospital authenticated read" on public.hospitals for select to authenticated using(true);
create policy "hospital staff manage" on public.hospitals for all to authenticated using(private.is_bloodbank_staff()) with check(private.is_bloodbank_staff());
create policy "donor owner or staff read" on public.donors for select to authenticated using(user_id=auth.uid() or private.is_bloodbank_staff());
create policy "donor insert pending" on public.donors for insert to authenticated with check(user_id=auth.uid() and status='pending');
create policy "donor owner update pending or staff" on public.donors for update to authenticated using(user_id=auth.uid() or private.is_bloodbank_staff()) with check((user_id=auth.uid() and status='pending') or private.is_bloodbank_staff());
create policy "donor staff delete" on public.donors for delete to authenticated using(private.is_bloodbank_staff());
create policy "screenings staff all" on public.donor_screenings for all to authenticated using(private.is_bloodbank_staff()) with check(private.is_bloodbank_staff());
create policy "donations staff all" on public.donations for all to authenticated using(private.is_bloodbank_staff()) with check(private.is_bloodbank_staff());
create policy "units staff all" on public.blood_units for all to authenticated using(private.is_bloodbank_staff()) with check(private.is_bloodbank_staff());
create policy "lab staff all" on public.lab_tests for all to authenticated using(private.is_bloodbank_staff()) with check(private.is_bloodbank_staff());
create policy "processing staff all" on public.processing_records for all to authenticated using(private.is_bloodbank_staff()) with check(private.is_bloodbank_staff());
create policy "requests owner or staff read" on public.blood_requests for select to authenticated using(requester_user_id=auth.uid() or private.is_bloodbank_staff());
create policy "request public pending insert" on public.blood_requests for insert to anon,authenticated with check(status='pending' and (requester_user_id is null or requester_user_id=auth.uid()));
create policy "requests staff update" on public.blood_requests for update to authenticated using(private.is_bloodbank_staff()) with check(private.is_bloodbank_staff());
create policy "compatibility staff all" on public.compatibility_tests for all to authenticated using(private.is_bloodbank_staff()) with check(private.is_bloodbank_staff());
create policy "issues staff all" on public.blood_issues for all to authenticated using(private.is_bloodbank_staff()) with check(private.is_bloodbank_staff());
create policy "transfusions staff all" on public.transfusion_records for all to authenticated using(private.is_bloodbank_staff()) with check(private.is_bloodbank_staff());
create policy "audit admin read" on public.audit_logs for select to authenticated using(private.is_bloodbank_admin());
create policy "audit staff insert" on public.audit_logs for insert to authenticated with check(private.is_bloodbank_staff());

grant select,insert,update,delete on public.profiles,public.hospitals,public.donors,public.donor_screenings,public.donations,public.blood_units,public.lab_tests,public.processing_records,public.blood_requests,public.compatibility_tests,public.blood_issues,public.transfusion_records,public.audit_logs to authenticated;
grant insert on public.blood_requests to anon;
grant usage,select on sequence public.audit_logs_id_seq to authenticated;
