# CTG Blood Bank

Repository target: **ctg-blood-bank**  
Blood donation, requests, inventory and staff workflow tracker built with React + TypeScript + Vite + Supabase.

## Included modules
- Splash screen → welcome screen → optional login/signup → app
- Dashboard metrics, activity chart and emergency queue
- Donor registration (date of birth, blood group, district, area, last donation, consent)
- Find donors with blood-group, district and text filters
- Normal/emergency blood request form and request status list
- Blood inventory cards, unit entry (quarantine-first), staff status updates
- Staff workflow modules: Screening, Lab Testing, Processing, Compatibility Testing, Authorized Issue, Transfusion Record
- PDF and XLSX export
- Responsive navigation for mobile/tablet/desktop
- Supabase Auth + table integration when environment variables are supplied; local demo storage fallback otherwise
- Supabase schema reference and Prisma reference schema

## Quick start
Node.js 20+ recommended.

```bash
npm install
cp .env.example .env
# Fill in Supabase URL and publishable/anon key if using Supabase
npm run dev
```
Open the Vite URL printed in the terminal (normally http://localhost:5173).

## Environment variables
Set only browser-safe keys in `.env`:
- `VITE_SUPABASE_URL`
- `VITE_SUPABASE_ANON_KEY` (publishable/anon key only; NEVER use a service-role or secret key in this app)

Without those variables the app runs local demo mode and stores demo records in the browser's localStorage.

## Database
- `supabase/schema.sql` is a reference for a **fresh project** with the CTG Blood Bank schema and restrictive RLS.
- The connected Supabase project already has its own schema and policies. Do **not** paste this fresh-project schema into an existing database without a schema diff. The current app maps donors to `date_of_birth`, `status`, `available`; requests to `requester_user_id`, `phone`, `units`, and `needed_by`.
- Auth role comes from the profile's `role` or staff/admin JWT app metadata. Promote staff/admin roles only through a trusted admin path in Supabase—not client-side user metadata.
- RLS should be reviewed and security advisors run before production. Donor contact data is sensitive; this project intentionally does not make donor phone lists public.

## Workflow and safety
The app is an operational tracker, not a clinical decision-support system. Donor eligibility, infectious disease screening, component processing, compatibility testing, release authorization, and transfusion monitoring must be performed and documented by qualified blood-bank staff using approved protocols. Do not use demo/local records for patient care.

## Build
```bash
npm run build
```
The build has not been verified in this environment because dependency installation timed out. The TSX source was syntax-transpiled separately after fixes; a complete typecheck/build still requires dependencies.

## GitHub
Target repository name: `ctg-blood-bank`. The connected GitHub repo currently remains `blood-life-connect`; rename it in GitHub Settings or create the new repository and push the project. This workspace does not have a direct filesystem-to-GitHub push path for these generated files.

## Reference visual style

The interface uses a red-and-white blood donation visual system inspired by the supplied mobile UI reference: clean rounded cards, crimson primary actions, soft neutral background, clear onboarding and mobile-first navigation.
